"""
FocusFlow - A productivity and health tracking application.
"""

__version__ = "1.0.0"
