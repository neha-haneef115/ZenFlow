from setuptools import setup, find_packages

setup(
    name="zenflowapp",
    version="0.1.0",

    packages=find_packages(),
    install_requires=[
        "PyQt5>=5.15.0",
        # System integration deps (mainly needed on Windows)
        "psutil>=5.9.5; sys_platform == 'win32'",
        "pywin32>=311; sys_platform == 'win32'",
    ],
    entry_points={
        "console_scripts": [
            "zenflowapp = src.main:main",
        ],
    },

    include_package_data=True,
    author="Neha Haneef",
    description="ZenFlow - Focus & Productivity App",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/neha-haneef115/ZenFlow",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
)
